import"./entry.095ea5d9.js";const t=""+new URL("poster.e61af223.jpg",import.meta.url).href;export{t as _};
