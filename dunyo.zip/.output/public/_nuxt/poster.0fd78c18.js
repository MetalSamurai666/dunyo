import"./entry.095ea5d9.js";const t=""+new URL("poster.44ed58f7.png",import.meta.url).href;export{t as _};
