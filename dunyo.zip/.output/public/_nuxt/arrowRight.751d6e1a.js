import"./entry.095ea5d9.js";const t=""+new URL("arrowRight.f2817952.svg",import.meta.url).href;export{t as _};
