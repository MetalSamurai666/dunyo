const client_manifest = {
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_arrowRight.751d6e1a.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "arrowRight.f2817952.svg"
    ],
    "file": "arrowRight.751d6e1a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "arrowRight.f2817952.svg": {
    "file": "arrowRight.f2817952.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_breadcrumbs.ab265556.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "breadcrumbs.a8e23d5e.css"
    ],
    "file": "breadcrumbs.ab265556.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "breadcrumbs.a8e23d5e.css": {
    "file": "breadcrumbs.a8e23d5e.css",
    "resourceType": "style"
  },
  "_cardCat.d86c01a9.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "cardCat.e0b72749.css"
    ],
    "file": "cardCat.d86c01a9.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "cardCat.e0b72749.css": {
    "file": "cardCat.e0b72749.css",
    "resourceType": "style"
  },
  "_catMore.015190c5.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "catMore.ec7db19e.css"
    ],
    "file": "catMore.015190c5.js",
    "imports": [
      "_cardCat.d86c01a9.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "catMore.ec7db19e.css": {
    "file": "catMore.ec7db19e.css",
    "resourceType": "style"
  },
  "_footer.ae74d5db.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "cloudRizzel.c90d04b0.svg",
      "logo.f3c617bd.png",
      "magnifier.38d85147.svg",
      "calendar.66b3410a.svg",
      "menu.8c8c2cbb.svg",
      "close.43b15e29.svg",
      "globe.c20f87d8.svg",
      "youtube.9251ccab.svg"
    ],
    "css": [
      "footer.93d152f7.css"
    ],
    "file": "footer.ae74d5db.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrowRight.751d6e1a.js",
      "_twitter.83f01548.js"
    ]
  },
  "footer.93d152f7.css": {
    "file": "footer.93d152f7.css",
    "resourceType": "style"
  },
  "cloudRizzel.c90d04b0.svg": {
    "file": "cloudRizzel.c90d04b0.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "logo.f3c617bd.png": {
    "file": "logo.f3c617bd.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "magnifier.38d85147.svg": {
    "file": "magnifier.38d85147.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "calendar.66b3410a.svg": {
    "file": "calendar.66b3410a.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "menu.8c8c2cbb.svg": {
    "file": "menu.8c8c2cbb.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "close.43b15e29.svg": {
    "file": "close.43b15e29.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "globe.c20f87d8.svg": {
    "file": "globe.c20f87d8.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "youtube.9251ccab.svg": {
    "file": "youtube.9251ccab.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_galleryList.b036b06f.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "galleryList.f4dfe386.css"
    ],
    "file": "galleryList.b036b06f.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "galleryList.f4dfe386.css": {
    "file": "galleryList.f4dfe386.css",
    "resourceType": "style"
  },
  "_layout.e916bf49.js": {
    "resourceType": "script",
    "module": true,
    "file": "layout.e916bf49.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.de9299b0.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.de9299b0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_poster.0fd78c18.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "poster.44ed58f7.png"
    ],
    "file": "poster.0fd78c18.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "poster.44ed58f7.png": {
    "file": "poster.44ed58f7.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_poster.85009935.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "poster.e61af223.jpg"
    ],
    "file": "poster.85009935.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "poster.e61af223.jpg": {
    "file": "poster.e61af223.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "_singleWelcome.23beb8b1.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "singleWelcome.cf8bf46c.css"
    ],
    "file": "singleWelcome.23beb8b1.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "singleWelcome.cf8bf46c.css": {
    "file": "singleWelcome.cf8bf46c.css",
    "resourceType": "style"
  },
  "_sponsors.4606464e.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "sponsors1.b23c4861.png"
    ],
    "css": [
      "sponsors.3025db7d.css"
    ],
    "file": "sponsors.4606464e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_layout.e916bf49.js"
    ]
  },
  "sponsors.3025db7d.css": {
    "file": "sponsors.3025db7d.css",
    "resourceType": "style"
  },
  "sponsors1.b23c4861.png": {
    "file": "sponsors1.b23c4861.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_twitter.83f01548.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "telegram.f273e1c1.svg",
      "facebook.f67284dd.svg",
      "twitter.860c2983.svg"
    ],
    "file": "twitter.83f01548.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "telegram.f273e1c1.svg": {
    "file": "telegram.f273e1c1.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "facebook.f67284dd.svg": {
    "file": "facebook.f67284dd.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "twitter.860c2983.svg": {
    "file": "twitter.860c2983.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_video.927a6a53.js": {
    "resourceType": "script",
    "module": true,
    "file": "video.927a6a53.js"
  },
  "assets/img/economy/poster.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "poster.e61af223.jpg",
    "src": "assets/img/economy/poster.jpg"
  },
  "assets/img/poster.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "poster.44ed58f7.png",
    "src": "assets/img/poster.png"
  },
  "assets/img/sponsors/sponsors1.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "sponsors1.b23c4861.png",
    "src": "assets/img/sponsors/sponsors1.png"
  },
  "assets/img/video_poster.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "video_poster.41d9a3e5.jpg",
    "src": "assets/img/video_poster.jpg"
  },
  "assets/logo/basic/arrowRight.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "arrowRight.f2817952.svg",
    "src": "assets/logo/basic/arrowRight.svg"
  },
  "assets/logo/basic/calendar.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "calendar.66b3410a.svg",
    "src": "assets/logo/basic/calendar.svg"
  },
  "assets/logo/basic/close.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "close.43b15e29.svg",
    "src": "assets/logo/basic/close.svg"
  },
  "assets/logo/basic/cloudRizzel.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "cloudRizzel.c90d04b0.svg",
    "src": "assets/logo/basic/cloudRizzel.svg"
  },
  "assets/logo/basic/globe.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "globe.c20f87d8.svg",
    "src": "assets/logo/basic/globe.svg"
  },
  "assets/logo/basic/magnifier.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "magnifier.38d85147.svg",
    "src": "assets/logo/basic/magnifier.svg"
  },
  "assets/logo/basic/menu.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "menu.8c8c2cbb.svg",
    "src": "assets/logo/basic/menu.svg"
  },
  "assets/logo/contacts/location.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "location.404839d7.svg",
    "src": "assets/logo/contacts/location.svg"
  },
  "assets/logo/contacts/mail.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "mail.c017e7d2.svg",
    "src": "assets/logo/contacts/mail.svg"
  },
  "assets/logo/contacts/phone.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "phone.8a48ef23.svg",
    "src": "assets/logo/contacts/phone.svg"
  },
  "assets/logo/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.f3c617bd.png",
    "src": "assets/logo/logo.png"
  },
  "assets/logo/socials/facebook.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "facebook.f67284dd.svg",
    "src": "assets/logo/socials/facebook.svg"
  },
  "assets/logo/socials/instagram.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "instagram.bfa38897.svg",
    "src": "assets/logo/socials/instagram.svg"
  },
  "assets/logo/socials/telegram.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "telegram.f273e1c1.svg",
    "src": "assets/logo/socials/telegram.svg"
  },
  "assets/logo/socials/twitter.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "twitter.860c2983.svg",
    "src": "assets/logo/socials/twitter.svg"
  },
  "assets/logo/socials/vk.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "vk.9b1675d3.svg",
    "src": "assets/logo/socials/vk.svg"
  },
  "assets/logo/socials/youtube.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "youtube.9251ccab.svg",
    "src": "assets/logo/socials/youtube.svg"
  },
  "breadcrumbs.css": {
    "resourceType": "style",
    "file": "breadcrumbs.a8e23d5e.css",
    "src": "breadcrumbs.css"
  },
  "cardCat.css": {
    "resourceType": "style",
    "file": "cardCat.e0b72749.css",
    "src": "cardCat.css"
  },
  "catMore.css": {
    "resourceType": "style",
    "file": "catMore.ec7db19e.css",
    "src": "catMore.css"
  },
  "footer.css": {
    "resourceType": "style",
    "file": "footer.93d152f7.css",
    "src": "footer.css"
  },
  "galleryList.css": {
    "resourceType": "style",
    "file": "galleryList.f4dfe386.css",
    "src": "galleryList.css"
  },
  "i18n.config.ts?hash=8fc192ef&config=1": {
    "resourceType": "script",
    "module": true,
    "file": "i18n.config.932ab037.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=8fc192ef&config=1"
  },
  "layouts/alt-header.vue": {
    "resourceType": "script",
    "module": true,
    "file": "alt-header.97b6a474.js",
    "imports": [
      "_footer.ae74d5db.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.de9299b0.js",
      "_arrowRight.751d6e1a.js",
      "_twitter.83f01548.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/alt-header.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.a3f46fd7.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "default.a3f46fd7.css"
    ],
    "file": "default.ee539c1f.js",
    "imports": [
      "_footer.ae74d5db.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.de9299b0.js",
      "_arrowRight.751d6e1a.js",
      "_twitter.83f01548.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.a3f46fd7.css": {
    "file": "default.a3f46fd7.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.7fc72018.css"
    ],
    "file": "error-404.fa8eb441.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.c5df6088.css"
    ],
    "file": "error-500.fd4a31ee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.2d89f70f.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.2d89f70f.css"
    ],
    "dynamicImports": [
      "layouts/alt-header.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=8fc192ef&config=1",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.095ea5d9.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.2d89f70f.css": {
    "file": "entry.2d89f70f.css",
    "resourceType": "style"
  },
  "pages/[cat]/[slug].css": {
    "resourceType": "style",
    "file": "_slug_.559afd87.css",
    "src": "pages/[cat]/[slug].css"
  },
  "pages/[cat]/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "vk.9b1675d3.svg"
    ],
    "css": [
      "_slug_.559afd87.css"
    ],
    "file": "_slug_.0a9c9e0a.js",
    "imports": [
      "_singleWelcome.23beb8b1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_twitter.83f01548.js",
      "_layout.e916bf49.js",
      "_cardCat.d86c01a9.js",
      "_catMore.015190c5.js",
      "_nuxt-link.de9299b0.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[cat]/[slug].vue"
  },
  "_slug_.559afd87.css": {
    "file": "_slug_.559afd87.css",
    "resourceType": "style"
  },
  "vk.9b1675d3.svg": {
    "file": "vk.9b1675d3.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/[cat]/index.css": {
    "resourceType": "style",
    "file": "index.5c4e6b4b.css",
    "src": "pages/[cat]/index.css"
  },
  "pages/[cat]/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.5c4e6b4b.css"
    ],
    "file": "index.f1b5df6d.js",
    "imports": [
      "_breadcrumbs.ab265556.js",
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_poster.0fd78c18.js",
      "_cardCat.d86c01a9.js",
      "_catMore.015190c5.js",
      "_sponsors.4606464e.js",
      "_layout.e916bf49.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[cat]/index.vue"
  },
  "index.5c4e6b4b.css": {
    "file": "index.5c4e6b4b.css",
    "resourceType": "style"
  },
  "pages/contacts.css": {
    "resourceType": "style",
    "file": "contacts.bd7994f7.css",
    "src": "pages/contacts.css"
  },
  "pages/contacts.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "location.404839d7.svg",
      "phone.8a48ef23.svg",
      "mail.c017e7d2.svg"
    ],
    "css": [
      "contacts.bd7994f7.css"
    ],
    "file": "contacts.73526cdd.js",
    "imports": [
      "_sponsors.4606464e.js",
      "_layout.e916bf49.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contacts.vue"
  },
  "contacts.bd7994f7.css": {
    "file": "contacts.bd7994f7.css",
    "resourceType": "style"
  },
  "location.404839d7.svg": {
    "file": "location.404839d7.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "phone.8a48ef23.svg": {
    "file": "phone.8a48ef23.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "mail.c017e7d2.svg": {
    "file": "mail.c017e7d2.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/gallery/[id].css": {
    "resourceType": "style",
    "file": "_id_.fb9835b2.css",
    "src": "pages/gallery/[id].css"
  },
  "pages/gallery/[id].vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "_id_.fb9835b2.css"
    ],
    "file": "_id_.776ed550.js",
    "imports": [
      "_singleWelcome.23beb8b1.js",
      "_layout.e916bf49.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_catMore.015190c5.js",
      "_nuxt-link.de9299b0.js",
      "_cardCat.d86c01a9.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gallery/[id].vue"
  },
  "_id_.fb9835b2.css": {
    "file": "_id_.fb9835b2.css",
    "resourceType": "style"
  },
  "pages/gallery/index.css": {
    "resourceType": "style",
    "file": "index.9a430d61.css",
    "src": "pages/gallery/index.css"
  },
  "pages/gallery/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.9a430d61.css"
    ],
    "file": "index.10793b2e.js",
    "imports": [
      "_breadcrumbs.ab265556.js",
      "_galleryList.b036b06f.js",
      "_catMore.015190c5.js",
      "_sponsors.4606464e.js",
      "_layout.e916bf49.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_poster.85009935.js",
      "_nuxt-link.de9299b0.js",
      "_cardCat.d86c01a9.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gallery/index.vue"
  },
  "index.9a430d61.css": {
    "file": "index.9a430d61.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.25e844cd.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "video_poster.41d9a3e5.jpg"
    ],
    "css": [
      "index.25e844cd.css"
    ],
    "file": "index.77f9e8cf.js",
    "imports": [
      "_nuxt-link.de9299b0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrowRight.751d6e1a.js",
      "_layout.e916bf49.js",
      "_poster.0fd78c18.js",
      "_cardCat.d86c01a9.js",
      "_video.927a6a53.js",
      "_galleryList.b036b06f.js",
      "_sponsors.4606464e.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.25e844cd.css": {
    "file": "index.25e844cd.css",
    "resourceType": "style"
  },
  "video_poster.41d9a3e5.jpg": {
    "file": "video_poster.41d9a3e5.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/videos.css": {
    "resourceType": "style",
    "file": "videos.2da9c9c1.css",
    "src": "pages/videos.css"
  },
  "pages/videos.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "videos.2da9c9c1.css"
    ],
    "file": "videos.66e31d27.js",
    "imports": [
      "_breadcrumbs.ab265556.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_catMore.015190c5.js",
      "_sponsors.4606464e.js",
      "_layout.e916bf49.js",
      "_poster.85009935.js",
      "_video.927a6a53.js",
      "_nuxt-link.de9299b0.js",
      "_cardCat.d86c01a9.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/videos.vue"
  },
  "videos.2da9c9c1.css": {
    "file": "videos.2da9c9c1.css",
    "resourceType": "style"
  },
  "singleWelcome.css": {
    "resourceType": "style",
    "file": "singleWelcome.cf8bf46c.css",
    "src": "singleWelcome.css"
  },
  "sponsors.css": {
    "resourceType": "style",
    "file": "sponsors.3025db7d.css",
    "src": "sponsors.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
