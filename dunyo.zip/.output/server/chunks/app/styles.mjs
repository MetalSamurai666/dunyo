const styles = {};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
