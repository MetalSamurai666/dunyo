import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "alt-header" | "default"
declare module "F:/work/grandsoft/dunyo/dunyo/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}