<script setup></script>

<template>
    <div>
        <Header class="secondary"/> 
        <Search /> 
        <Menu />
        <slot/>
        
        <Footer />
    </div>
</template>

<style lang="scss">
</style>