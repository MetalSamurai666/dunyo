<script setup></script>

<template>
    <div>
        <Header />
        <Search />
        <Menu />
        <slot/>
        
        <Footer />
        <Old />
    </div>
</template>

<style lang="scss">
</style>